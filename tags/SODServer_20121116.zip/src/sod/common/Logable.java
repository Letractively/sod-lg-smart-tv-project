package sod.common;

public interface Logable {
	void log(Object arg);
}

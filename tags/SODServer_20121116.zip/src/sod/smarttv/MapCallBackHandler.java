package sod.smarttv;

/**
 * 
 * @author MB
 *
 */
public interface MapCallBackHandler {
	
	/**
	 * called from framework when it needed to show map service.
	 */
	void showMap();
}


package com.sgsong.Sound;

public class SND_INFO
{
	public boolean bSet;
	public long startTime;
	public int	nID;
	
	public SND_INFO()
	{
		bSet = false;
		startTime = 0;
		nID = -1;
	}
}

package com.sgsong.Element;

public class NumberInfo
{	
	public ElementPart	vNum;
	public int			divideNum;
	public int			mNum;
	public boolean		bShow;
	
	public NumberInfo()
	{		
	}	
}

package com.sgsong.Draw;

public class SG_RECT
{
	public int nLeft;
	public int nTop;
	public int nRight;
	public int nBottom;
	public int nCenterX;
	public int nCenterY;
	
	public SG_RECT()
	{		
	}
}
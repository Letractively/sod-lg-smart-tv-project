package com.sgsong.Net;

public class GCCBean {
	public static int MAX_COUNT_CARD = 10;
	public static String card_index="";
}

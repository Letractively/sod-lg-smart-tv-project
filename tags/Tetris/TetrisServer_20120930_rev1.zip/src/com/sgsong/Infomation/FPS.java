
package com.sgsong.Infomation;

public class FPS
{
	public int nCurFPS;
	public long nCurTime;
	public int nFPS;
	
	public static final int GAME_FPS = 30;

	public int n1000, n100, n10, n1;
	
	public FPS()
	{
		nCurFPS = 0;
		nCurTime = 0;
		nFPS = 0;
		
	}
}

package com.sgsong.Struct;

public class ImageInfo
{	
	public int nResID;	
	public int nImgStartX;
	public int nImgStartY;

	public int nImgWidth;
	public int nImgHeight;
	
	public ImageInfo()
	{
		
	}	
}
package sod.service;

public class ConnectionImpl {

}
